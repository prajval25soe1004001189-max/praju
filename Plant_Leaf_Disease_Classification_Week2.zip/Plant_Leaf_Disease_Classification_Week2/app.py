"""Streamlit interface for leaf image classification."""
from pathlib import Path
import json, os, numpy as np, streamlit as st, tensorflow as tf
from PIL import Image
st.set_page_config(page_title='Plant Leaf Classifier',page_icon='🌿',layout='centered')
st.title('🌿 Plant Leaf Disease Classifier'); st.caption('Deep learning educational demo — PlantVillage class labels')
model_path=os.getenv('MODEL_PATH','outputs/models/resnet50.keras'); labels_path=os.getenv('LABELS_PATH','outputs/class_names.json')
@st.cache_resource
def load_assets():
 model=tf.keras.models.load_model(model_path)
 names=json.loads(Path(labels_path).read_text())
 return model,names
if not Path(model_path).exists() or not Path(labels_path).exists():
 st.warning('Model files are missing. Train a model first and generate outputs/class_names.json.'); st.code('python src/train.py --model resnet50 --epochs 10'); st.stop()
model,names=load_assets(); uploaded=st.file_uploader('Upload a leaf photo',type=['jpg','jpeg','png'])
if uploaded:
 img=Image.open(uploaded).convert('RGB'); st.image(img,caption='Uploaded image',use_container_width=True)
 x=np.array(img.resize((224,224)),dtype=np.float32)[None,...]; probs=model.predict(x,verbose=0)[0]; order=np.argsort(probs)[::-1][:3]
 idx=int(order[0]); st.subheader('Prediction'); st.write(f'**{names[idx].replace("_"," ")}**'); st.metric('Model confidence',f'{probs[idx]*100:.1f}%')
 st.write('Top predictions'); st.bar_chart({names[int(i)].replace('_',' '):float(probs[i]) for i in order})
 st.info('Confidence is not a probability of real-world correctness. This model is trained on curated images and is not an agricultural diagnosis. Consult local agricultural expertise before taking action.')
