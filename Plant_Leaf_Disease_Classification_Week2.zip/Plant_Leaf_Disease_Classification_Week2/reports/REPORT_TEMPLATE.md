# Plant Leaf Disease Classification — Project Report

**Student:** [Name]  
**Course/Internship:** [Course]  
**Week:** 2 — Deep Learning  
**Dataset:** PlantVillage (Kaggle)  
**Models:** Custom CNN and ResNet50 transfer learning

## Abstract
This project investigates deep-learning-based classification of supported plant leaf health and disease categories from images. A custom CNN baseline is compared with ResNet50 transfer learning. The experiment uses a separated training, validation and held-out test workflow.

## 1. Problem statement
Describe the motivation, supported classes, intended users, and scope. The model classifies dataset labels; it does not provide diagnosis or treatment recommendations.

## 2. Dataset
Source link: https://www.kaggle.com/datasets/emmarex/plantdisease  
Report actual image counts, class counts, image formats, license/terms and any exclusions after running data preparation. Do not invent dataset statistics.

## 3. Methodology
- Stratified 70/15/15 split from the source images
- 224 × 224 image resizing
- Training augmentation (horizontal flip and rotation for ResNet pipeline)
- CNN baseline and ImageNet-pretrained ResNet50
- Adam optimizer and categorical class probabilities (sparse labels)
- Early stopping, best validation checkpoint, learning-rate reduction

## 4. Experiments and results
Fill with the generated test metrics after training. Compare models only when they use the same split and test set. Include accuracy, per-class precision/recall/F1, confusion matrix and notes on class imbalance.

## 5. Discussion
Discuss misclassifications, dataset bias, visual similarity between classes, overfitting, and limitations of curated backgrounds.

## 6. Conclusion and future work
Summarize findings based on measured results. Potential improvements: field-photo validation, fine-tuning, EfficientNet comparison, Grad-CAM and class imbalance handling.

## Responsible use
This is an educational prototype and should not be treated as a reliable agricultural diagnostic tool. Real-world validation and expert input are required.
