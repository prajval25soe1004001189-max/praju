# Plant Leaf Disease Classification (Week 2 - Deep Learning)

Professional educational image-classification pipeline for PlantVillage. Includes dataset preparation, custom CNN baseline, ResNet50 transfer learning, evaluation, plots, and Streamlit prediction app.


## Dataset
Download the PlantVillage dataset from Kaggle: https://www.kaggle.com/datasets/emmarex/plantdisease
After extraction, put class folders under `data/raw/PlantVillage/` (one folder per label). The dataset is not bundled in this repository.

**Important:** Train/validation/test are split from the raw folder before training. Do not use a pre-augmented split if it may contain related transformed images across splits. For any formal report, state dataset provenance and evaluate on the held-out test set only.


## Setup
Python 3.10-3.11 recommended.
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate | macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

1. Place extracted class folders in `data/raw/PlantVillage/`.
2. Split once: `python src/prepare_data.py --source data/raw/PlantVillage --output data/split --seed 42`
3. Train baseline CNN: `python src/train.py --model cnn --epochs 15`
4. Train transfer-learning model: `python src/train.py --model resnet50 --epochs 10`
5. Evaluate models: `python src/evaluate.py --model outputs/models/cnn.keras` (repeat for ResNet)
6. Launch app: `streamlit run app.py` (set `MODEL_PATH` in the app or use default `outputs/models/resnet50.keras`)

Training on the full dataset is resource-intensive. Use a GPU runtime (e.g., Colab) when available; reduce batch size or image count for a quick test.


## Project contents
- `src/prepare_data.py`: reproducible stratified split, copied into train/val/test folders
- `src/train.py`: custom CNN or ResNet50 transfer learning, checkpointing, logs
- `src/evaluate.py`: test metrics, classification report, confusion matrix and plots
- `app.py`: image upload prediction UI
- `notebooks/`: project workflow notebook starter
- `reports/`: report template
- `outputs/`: generated metrics, plots, and model files (not committed)

## Responsible use
This is a learning prototype. Predictions are not agronomic diagnosis or treatment advice. Images captured in real field conditions may differ substantially from curated dataset images; validate with field images and expert guidance before practical decisions.
