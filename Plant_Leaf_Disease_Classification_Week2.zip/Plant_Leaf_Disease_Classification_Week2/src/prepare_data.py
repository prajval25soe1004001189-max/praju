"""Create a reproducible stratified train/validation/test directory split."""
from pathlib import Path
import argparse, shutil, random
from sklearn.model_selection import train_test_split

EXTS={'.jpg','.jpeg','.png','.bmp','.webp'}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--source', default='data/raw/PlantVillage')
    p.add_argument('--output', default='data/split')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--train', type=float, default=.70)
    p.add_argument('--val', type=float, default=.15)
    p.add_argument('--test', type=float, default=.15)
    p.add_argument('--reset', action='store_true', help='Remove previous split folders before rebuilding')
    a=p.parse_args()
    if abs(a.train+a.val+a.test-1)>1e-6: raise ValueError('Split ratios must sum to 1')
    source=Path(a.source); out=Path(a.output)
    classes=sorted(d.name for d in source.iterdir() if d.is_dir()) if source.exists() else []
    if len(classes)<2: raise SystemExit(f'Expected class folders inside {source}. Dataset not found or layout invalid.')
    all_paths=[]; labels=[]
    for c in classes:
        imgs=sorted(x for x in (source/c).rglob('*') if x.is_file() and x.suffix.lower() in EXTS)
        if not imgs: print(f'[WARN] empty class folder: {c}')
        all_paths += imgs; labels += [c]*len(imgs)
    # Stratified split: test first, then validation from remaining training pool
    trval, test, ytrval, ytest=train_test_split(all_paths, labels, test_size=a.test, random_state=a.seed, stratify=labels)
    val_frac=a.val/(a.train+a.val)
    train, val, ytrain, yval=train_test_split(trval, ytrval, test_size=val_frac, random_state=a.seed, stratify=ytrval)
    splits={'train':(train,ytrain),'val':(val,yval),'test':(test,ytest)}
    if a.reset and out.exists(): shutil.rmtree(out)
    random.seed(a.seed)
    for split,(paths,ys) in splits.items():
        for path,label in zip(paths,ys):
            dest=out/split/label/path.name
            dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.exists(): dest=dest.with_name(f'{path.stem}_{random.randint(0,999999)}{path.suffix}')
            shutil.copy2(path,dest)
    print(f'Classes: {len(classes)} | Images: {len(all_paths)}')
    for split,(paths,_) in splits.items(): print(f'{split}: {len(paths)} ({len(paths)/len(all_paths):.1%})')
    print('Split complete. Use --reset to rebuild.')
if __name__=='__main__': main()
