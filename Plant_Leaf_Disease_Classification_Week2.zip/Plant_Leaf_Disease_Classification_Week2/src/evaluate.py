"""Evaluate saved Keras model on held-out test set and create plots/reports."""
from pathlib import Path
import argparse, json, numpy as np, tensorflow as tf, matplotlib.pyplot as plt
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score

def main():
 p=argparse.ArgumentParser(); p.add_argument('--model',required=True); p.add_argument('--data',default='data/split'); p.add_argument('--batch-size',type=int,default=32); a=p.parse_args()
 test=tf.keras.utils.image_dataset_from_directory(Path(a.data)/'test',image_size=(224,224),batch_size=a.batch_size,shuffle=False)
 names=test.class_names; model=tf.keras.models.load_model(a.model); y=[]; probs=[]
 for x,lab in test: probs.append(model.predict(x,verbose=0)); y.extend(lab.numpy().tolist())
 probs=np.concatenate(probs); pred=probs.argmax(axis=1); Path('outputs/plots').mkdir(parents=True,exist_ok=True)
 report=classification_report(y,pred,target_names=names,zero_division=0,digits=4); Path('outputs/test_classification_report.txt').write_text(report)
 print('Test accuracy:',round(accuracy_score(y,pred),4)); print(report)
 cm=confusion_matrix(y,pred); fig,ax=plt.subplots(figsize=(max(10,len(names)*.35),max(8,len(names)*.3))); im=ax.imshow(cm,cmap='Blues'); ax.set(title='Test Confusion Matrix',xlabel='Predicted',ylabel='True'); ax.set_xticks(range(len(names))); ax.set_yticks(range(len(names))); ax.set_xticklabels(names,rotation=90,fontsize=7); ax.set_yticklabels(names,fontsize=7); fig.colorbar(im); fig.tight_layout(); fig.savefig('outputs/plots/confusion_matrix.png',dpi=180); plt.close(fig)
 Path('outputs/test_metrics.json').write_text(json.dumps({'accuracy':float(accuracy_score(y,pred)),'n_test':len(y),'classes':names},indent=2))
if __name__=='__main__': main()
