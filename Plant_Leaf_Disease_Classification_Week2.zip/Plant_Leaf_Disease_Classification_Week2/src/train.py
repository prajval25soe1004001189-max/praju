"""Train a CNN baseline or ResNet50 transfer-learning model."""
from pathlib import Path
import argparse, json, tensorflow as tf
from tensorflow.keras import layers, models

IMG_SIZE=(224,224)

def build_cnn(n_classes):
    inp=layers.Input(shape=(*IMG_SIZE,3)); x=layers.Rescaling(1./255)(inp)
    for filters in (32,64,128):
        x=layers.Conv2D(filters,3,padding='same',activation='relu')(x)
        x=layers.BatchNormalization()(x); x=layers.MaxPooling2D()(x); x=layers.Dropout(.20)(x)
    x=layers.GlobalAveragePooling2D()(x); x=layers.Dense(256,activation='relu')(x); x=layers.Dropout(.35)(x)
    return models.Model(inp,layers.Dense(n_classes,activation='softmax')(x),name='custom_cnn')

def build_resnet(n_classes):
    base=tf.keras.applications.ResNet50(include_top=False,weights='imagenet',input_shape=(*IMG_SIZE,3))
    base.trainable=False
    inp=layers.Input(shape=(*IMG_SIZE,3)); x=layers.RandomFlip('horizontal')(inp); x=layers.RandomRotation(.08)(x)
    x=tf.keras.applications.resnet50.preprocess_input(x)
    x=base(x,training=False); x=layers.GlobalAveragePooling2D()(x); x=layers.Dropout(.3)(x)
    out=layers.Dense(n_classes,activation='softmax')(x)
    return models.Model(inp,out,name='resnet50_transfer'),base

def main():
    p=argparse.ArgumentParser(); p.add_argument('--model',choices=['cnn','resnet50'],default='cnn')
    p.add_argument('--epochs',type=int,default=15); p.add_argument('--batch-size',type=int,default=32)
    p.add_argument('--data',default='data/split'); p.add_argument('--seed',type=int,default=42); p.add_argument('--fine-tune',action='store_true')
    a=p.parse_args(); tf.keras.utils.set_random_seed(a.seed)
    data=Path(a.data)
    train=tf.keras.utils.image_dataset_from_directory(data/'train',image_size=IMG_SIZE,batch_size=a.batch_size,label_mode='int')
    val=tf.keras.utils.image_dataset_from_directory(data/'val',image_size=IMG_SIZE,batch_size=a.batch_size,label_mode='int',shuffle=False)
    names=train.class_names; n=len(names); autotune=tf.data.AUTOTUNE
    train=train.prefetch(autotune); val=val.prefetch(autotune)
    if a.model=='cnn': model=build_cnn(n); base=None
    else: model,base=build_resnet(n)
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3),loss='sparse_categorical_crossentropy',metrics=['accuracy'])
    Path('outputs/models').mkdir(parents=True,exist_ok=True); Path('outputs').mkdir(exist_ok=True)
    out=Path(f'outputs/models/{a.model}.keras')
    callbacks=[tf.keras.callbacks.ModelCheckpoint(out,monitor='val_accuracy',save_best_only=True),tf.keras.callbacks.EarlyStopping(monitor='val_loss',patience=4,restore_best_weights=True),tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss',factor=.3,patience=2),tf.keras.callbacks.CSVLogger(f'outputs/{a.model}_training_log.csv')]
    hist=model.fit(train,validation_data=val,epochs=a.epochs,callbacks=callbacks)
    if a.model=='resnet50' and a.fine_tune:
        base.trainable=True
        for layer in base.layers[:-30]: layer.trainable=False
        model.compile(optimizer=tf.keras.optimizers.Adam(1e-5),loss='sparse_categorical_crossentropy',metrics=['accuracy'])
        model.fit(train,validation_data=val,epochs=max(3,a.epochs//2),callbacks=callbacks)
    model.save(out)
    Path('outputs/class_names.json').write_text(json.dumps(names,indent=2))
    print(f'Saved model: {out}\\nClass labels saved: outputs/class_names.json')
if __name__=='__main__': main()
