Training outputs (models, metrics, plots) are generated locally after dataset download and training. No fabricated metrics are included in this package.
