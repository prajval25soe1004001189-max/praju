import streamlit as st
from src.tools import extract_resume_text
from src.agents import RecruitmentWorkflow
st.set_page_config(page_title='Recruitment Administration Assistant',page_icon='🧩',layout='wide')
st.title('🧩 Recruitment Administration Assistant')
st.caption('Week 4 Agentic AI demo · Administrative assistance only · No ranking or hiring decisions')
resume_demo='''Alex Morgan\nalex.morgan@example.test\nEDUCATION\nBSc Computer Science — Example University, 2022–2026\nSKILLS\nPython, SQL, Excel, Git, Data Analysis\nPROJECTS\nSales Dashboard — Built a dashboard and cleaned sample data.\nEXPERIENCE\nData Intern — Assisted with data validation and weekly reports.'''
jd_demo='''Junior Data Analyst\nResponsibilities:\n- Prepare and validate datasets\n- Create reports and dashboards\n- Collaborate with cross-functional teams\nRequirements:\nPython, SQL, Excel, communication, data analysis'''
with st.sidebar:
    st.header('Demo controls')
    if st.button('Load fictional example'):
        st.session_state.rtxt=resume_demo; st.session_state.jtxt=jd_demo
    st.info('Use fictional or consented candidate data. Logs contain summaries, not full documents.')
left,right=st.columns(2)
with left:
    st.subheader('Resume input')
    uploaded=st.file_uploader('Upload resume (PDF/DOCX/TXT)',type=['pdf','docx','txt'])
    resume=st.text_area('Or paste resume text',value=st.session_state.get('rtxt',''),height=300)
with right:
    st.subheader('Job description')
    jd=st.text_area('Paste job description',value=st.session_state.get('jtxt',''),height=370)
if st.button('Run agent workflow',type='primary'):
    try:
        if uploaded: resume=extract_resume_text(uploaded)
        if not resume.strip() or not jd.strip(): st.error('Provide both resume text and job description first.')
        else:
            wf=RecruitmentWorkflow()
            with st.spinner('Agents processing…'): res=wf.run(resume,jd)
            st.session_state.results=res; st.session_state.logs=wf.logs; st.session_state.wfstate=wf.state
    except Exception as e: st.error(f'Workflow error: {e}'); st.session_state.wfstate='ERROR'
if 'results' in st.session_state:
    res=st.session_state.results; st.divider(); st.success('Workflow state: '+st.session_state.get('wfstate','COMPLETED'))
    t1,t2,t3,t4=st.tabs(['Candidate profile','JD analysis','Interview questions','Invocation logs'])
    with t1: st.json(res['profile'])
    with t2: st.json(res['job_description'])
    with t3:
        for n,q in enumerate(res['interview']['questions'],1): st.write(f'{n}. {q}')
        st.caption(res['interview']['note'])
    with t4: st.dataframe(st.session_state.logs,use_container_width=True)
    st.warning('Human review required. This tool does not rank, score, reject, or select applicants.')
