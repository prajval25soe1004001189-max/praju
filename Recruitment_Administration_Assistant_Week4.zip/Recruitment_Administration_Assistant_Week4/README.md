# Recruitment Administration Assistant — Week 4 Agentic AI

A runnable prototype that organizes candidate-provided resume information, analyzes job descriptions, and drafts interview questions. It intentionally does **not** rank, score, reject, select, or recommend candidates.

## Agents
- Resume Information Extractor
- Job Description Analyzer
- Interview Preparation Assistant
- Workflow Supervisor (state and logs)

## Tools
Resume Text Extractor (PDF/DOCX/TXT), Job Description Parser, Candidate Profile Formatter, Interview Question Generator.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```
Click **Load fictional example**, then **Run agent workflow** to demonstrate state and tool invocation logs.

## States
`IDLE → RESUME_PROCESSING → JD_ANALYSIS → INTERVIEW_PREPARATION → COMPLETED`; failures move to `ERROR`.

## Privacy & limitations
Use fictional or consented data. This is a heuristic demonstration; extraction can miss information. Do not use it for employment decisions. Review every output against the original documents.
