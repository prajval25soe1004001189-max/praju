import re, io

def extract_resume_text(uploaded_file):
    name=uploaded_file.name.lower(); raw=uploaded_file.getvalue()
    if name.endswith('.txt'): return raw.decode('utf-8',errors='replace')
    if name.endswith('.pdf'):
        from pypdf import PdfReader
        return '\n'.join(p.extract_text() or '' for p in PdfReader(io.BytesIO(raw)).pages)
    if name.endswith('.docx'):
        from docx import Document
        return '\n'.join(p.text for p in Document(io.BytesIO(raw)).paragraphs)
    raise ValueError('Unsupported file type. Upload PDF, DOCX, or TXT.')

def parse_job_description(text):
    if not text.strip(): raise ValueError('Job description is empty.')
    lines=[s.strip(' •-*\t') for s in text.splitlines() if s.strip()]
    vocabulary=['Python','SQL','Excel','Communication','Project Management','Machine Learning','Data Analysis','Java','JavaScript','Cloud','Testing','Git','Power BI','Leadership']
    detected=[v for v in vocabulary if re.search(re.escape(v),text,re.I)]
    return {'responsibility_lines':[x for x in lines if len(x)>18][:10], 'recognized_terms':detected, 'source_note':'Extracted from the provided job description.'}

def format_candidate_profile(text):
    if not text.strip(): raise ValueError('Resume text is empty.')
    email=re.search(r'[\w.+-]+@[\w-]+(?:\.[\w-]+)+',text)
    phone=re.search(r'(?:\+?\d[\d ()-]{7,}\d)',text)
    vocab=['Python','Java','C++','SQL','Excel','Power BI','Tableau','Machine Learning','Deep Learning','Communication','Leadership','HTML','CSS','JavaScript','Git','Data Analysis','Project Management','TensorFlow','PyTorch']
    skills=[s for s in vocab if re.search(re.escape(s),text,re.I)]
    return {'contact_email':email.group(0) if email else 'Not stated in resume','contact_phone':phone.group(0) if phone else 'Not stated in resume','skills_explicitly_detected':skills or ['No recognized skills found'],'resume_excerpt':' '.join(text.split())[:500],'sections_detected':[h for h in ['Education','Experience','Projects','Skills','Certifications'] if re.search(h,text,re.I)], 'disclaimer':'Extraction may be incomplete. Review against the original resume.'}

def generate_interview_questions(profile,jd):
    topics=jd.get('recognized_terms',[])[:5]
    qs=['Please describe a project or experience listed in your resume and your own contribution.','What challenge did you encounter in that experience, and how did you approach it?','Can you walk through how you learned or applied one of the skills listed in your resume?']
    if topics: qs.append('The job description mentions '+', '.join(topics)+'. Which of these have you encountered, and could you describe your experience?')
    qs += ['How would you clarify priorities when a task has incomplete requirements?','What questions would you like to ask about this role or team?']
    return {'questions':qs,'note':'Draft interview prompts for human review. Do not use them to automatically evaluate or make employment decisions.'}
