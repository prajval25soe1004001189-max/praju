from datetime import datetime
from src.tools import parse_job_description, format_candidate_profile, generate_interview_questions
class RecruitmentWorkflow:
    def __init__(self): self.state='IDLE'; self.logs=[]
    def log(self,agent,tool,status,summary='',error=None): self.logs.append({'time':datetime.now().strftime('%H:%M:%S'),'agent':agent,'tool':tool,'status':status,'summary':summary,'error':error})
    def run(self,resume,jd):
        try:
            self.state='RESUME_PROCESSING'; self.log('Resume Extractor Agent','Candidate Profile Formatter','RUNNING')
            profile=format_candidate_profile(resume); self.log('Resume Extractor Agent','Candidate Profile Formatter','SUCCESS','Profile structured')
            self.state='JD_ANALYSIS'; self.log('Job Description Agent','Job Description Parser','RUNNING')
            job=parse_job_description(jd); self.log('Job Description Agent','Job Description Parser','SUCCESS','Requirements organized')
            self.state='INTERVIEW_PREPARATION'; self.log('Interview Preparation Agent','Interview Question Generator','RUNNING')
            interview=generate_interview_questions(profile,job); self.log('Interview Preparation Agent','Interview Question Generator','SUCCESS','Draft questions created')
            self.state='COMPLETED'; self.log('Workflow Supervisor','Workflow Assembly','COMPLETED','All workflow stages finished')
            return {'profile':profile,'job_description':job,'interview':interview}
        except Exception as exc:
            self.state='ERROR'; self.log('Workflow Supervisor','Workflow Execution','ERROR','Workflow failed',str(exc)); raise
