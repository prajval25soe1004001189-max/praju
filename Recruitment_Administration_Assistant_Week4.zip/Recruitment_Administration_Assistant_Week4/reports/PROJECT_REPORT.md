# Recruitment Administration Assistant — Week 4 Agentic AI

## Abstract
This prototype coordinates specialized roles to organize candidate-provided resume information, extract job-description requirements, and draft interview questions. It is administrative support, not a decision-making system.

## Objectives
- Parse resume text from PDF, DOCX, or TXT.
- Extract supported skills and candidate-provided profile information.
- Organize job description responsibilities and skill terms.
- Draft neutral interview questions using supplied materials.
- Demonstrate multi-agent roles, workflow state, functional tools, invocation logs, and error handling.

## Agents and tools
Resume Information Extractor (Candidate Profile Formatter), Job Description Analyzer (Job Description Parser), Interview Preparation Assistant (Interview Question Generator), and Workflow Supervisor. Resume Text Extractor is the fourth tool.

## Workflow states
IDLE → RESUME_PROCESSING → JD_ANALYSIS → INTERVIEW_PREPARATION → COMPLETED; error path transitions to ERROR.

## Human oversight and safety
No ranking, scoring, rejection, selection, or hiring recommendation is implemented. The system does not infer protected or sensitive traits. Heuristic extraction may be incomplete. Human HR staff must verify all output. Use fictional/consented data and minimize retention.

## Demonstration
Load the fictional example in Streamlit. Run the workflow and inspect profile, JD analysis, interview question draft, and invocation logs. Validate missing input and unsupported-file error paths.

## Evaluation checklist
- Test PDF, DOCX, TXT parsing.
- Check detected candidate fields against source.
- Check JD parsing coverage.
- Review generated questions for neutrality and relevance.
- Confirm logs show timestamps, tool, status, and summaries.
- Confirm missing inputs and unsupported formats yield visible errors.
