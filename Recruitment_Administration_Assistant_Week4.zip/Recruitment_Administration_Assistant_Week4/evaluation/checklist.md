# Demo checklist
- [ ] Install requirements and start Streamlit
- [ ] Load fictional demo inputs
- [ ] Run workflow and verify COMPLETED state
- [ ] Review profile extraction, JD analysis, and questions
- [ ] Inspect invocation logs
- [ ] Test missing resume and missing JD errors
- [ ] Test unsupported file format
- [ ] Verify no candidate score/ranking/selection/rejection output
