# Medical Research Literature Assistant (GEN-02)

A professional educational Retrieval-Augmented Generation (RAG) project that retrieves passages from open-access biomedical literature and prepares evidence-grounded responses with source links.


## Features
- PMC article ingestion using the NCBI BioC API (manual PMC IDs)
- Passage chunking with overlap and article metadata
- Sentence Transformers embeddings (`all-MiniLM-L6-v2`) when installed
- FAISS-compatible project direction; current retrieval implementation uses cosine similarity for Sentence Transformers and a lexical overlap fallback when embedding dependencies are unavailable
- Answer generation via OpenAI-compatible API, Ollama, or transparent evidence-only extractive fallback
- Inline source labels `[S1]` and expandable source passages in Streamlit
- Comparison-ready retrieval pipeline, evaluation smoke tests, and report/notebook starter
- Abstains when no relevant retrieved passages are found


## Quick start

### 1. Python environment
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Fetch PMC articles
Only use article IDs that are available for open-access reuse. Confirm reuse/license information for each paper before redistributing article text.

```bash
python src/ingest.py PMC_ID_1 PMC_ID_2
```
Replace the example IDs with real PMC IDs. This writes `data/articles.json`.

### 3. Build local index artifacts

```bash
python src/build_index.py
```

### 4. Launch the interface

```bash
streamlit run app.py
```

### 5. Run retrieval smoke tests

```bash
python src/evaluation.py
```

## Answer generation options

- **Auto:** Uses OpenAI if `OPENAI_API_KEY` exists; otherwise Ollama if `OLLAMA_MODEL` is set; otherwise evidence-only output.
- **OpenAI:** Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` (default `gpt-4o-mini`).
- **Ollama:** Install/run Ollama locally and set `OLLAMA_MODEL` (default `llama3.1`); optionally `OLLAMA_HOST`.
- **Extractive:** Does not call a generative model. Shows retrieved excerpts transparently.


Create a local `.env` file from `.env.example` and set your chosen configuration. The project does not commit secrets.


## Folder structure

```text
Medical_Research_Literature_Assistant_GEN02/
├── app.py
├── requirements.txt
├── .env.example
├── src/                    # ingestion, chunking, embedding, retrieval, generation, evaluation
├── data/                    # articles.json created by ingestion; empty starter included
├── vector_db/                # chunks and embeddings created by build_index.py
├── evaluation/                # sample questions and smoke-test outputs
├── notebooks/                 # workflow notebook
├── reports/                   # report templates and generated project report
└── outputs/                    # generated output location
```

## Important limitations and responsible use
- This is a research-literature assistant, **not** a medical diagnosis or treatment system.
- It may miss papers, retrieve irrelevant passages, or misinterpret study context. Always verify generated statements in the original paper.
- Citation labels link to retrieved articles but do not guarantee every generated sentence is fully supported. Review the retrieved evidence and source text.
- Results depend on the papers actually ingested and their accessibility/license status.
- The included evaluation is a smoke-test scaffold, not a validated RAG benchmark.
- Do not ingest patient-identifiable information.
- Do not redistribute article full text unless its license permits it.

## Troubleshooting
- If the embedding package/model is unavailable, retrieval falls back to lexical overlap; this is less capable than semantic search.
- If no articles are indexed, ingest PMC IDs before opening the app.
- If LLM credentials or local service are absent, the app uses evidence-only excerpts rather than fabricating a synthesized answer.

## Academic disclosure
Report the actual articles ingested, model/provider used, runtime settings, and measured evaluation results. Do not report placeholder, unrun, or synthetic metrics as real performance.
