"""RAG core: chunking, embeddings (optional Sentence Transformers), retrieval, and grounded generation."""
import json, re, os
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
ARTICLES=ROOT/"data"/"articles.json"

def load_articles(path=ARTICLES):
    p=Path(path)
    if not p.exists(): return []
    return json.loads(p.read_text(encoding="utf-8"))

def make_chunks(articles, chunk_words=220, overlap_words=40):
    chunks=[]
    for article in articles:
        for passage in article.get("passages", []):
            words=passage.get("text", "").split()
            if not words: continue
            step=max(1,chunk_words-overlap_words)
            for start in range(0,len(words),step):
                piece=" ".join(words[start:start+chunk_words]).strip()
                if len(piece)<40: continue
                chunks.append({"text":piece,"title":article.get("title","Untitled"),"pmcid":article.get("pmcid",""),"url":article.get("url",""),"section":passage.get("section","text")})
                if start+chunk_words>=len(words): break
    return chunks

class Embedder:
    def __init__(self, model_name="sentence-transformers/all-MiniLM-L6-v2"):
        self.model=None; self.model_name=model_name
        try:
            from sentence_transformers import SentenceTransformer
            self.model=SentenceTransformer(model_name)
        except Exception:
            self.model=None
    def encode(self, texts):
        if self.model is not None:
            return np.asarray(self.model.encode(texts, normalize_embeddings=True, show_progress_bar=False), dtype="float32")
        # Dependency-light lexical fallback: token-frequency vectors, with vocabulary shared across batch.
        tokens=[re.findall(r"[a-zA-Z0-9]+",t.lower()) for t in texts]
        vocab=sorted({w for doc in tokens for w in doc})
        idx={w:i for i,w in enumerate(vocab)}
        mat=np.zeros((len(tokens),len(vocab)),dtype="float32")
        for i,doc in enumerate(tokens):
            for w in doc: mat[i,idx[w]]+=1
        norms=np.linalg.norm(mat,axis=1,keepdims=True); norms[norms==0]=1
        return mat/norms

class Retriever:
    def __init__(self,chunks,embedder=None):
        self.chunks=chunks; self.embedder=embedder or Embedder()
        self.embeddings=self.embedder.encode([c["text"] for c in chunks]) if chunks else np.empty((0,0))
    def search(self,query,k=5):
        if not self.chunks: return []
        qv=self.embedder.encode([query])[0]
        # sentence-transformer vectors are normalized. Fallback vector dimensions are batch-local,
        # so use a simple overlap score for fallback to avoid incompatible dimensions.
        if self.embedder.model is None:
            qwords=set(re.findall(r"[a-zA-Z0-9]+",query.lower()))
            scored=[]
            for c in self.chunks:
                words=set(re.findall(r"[a-zA-Z0-9]+",c["text"].lower()))
                score=len(qwords&words)/max(1,len(qwords))
                scored.append((score,c))
            return [dict(c,score=float(s)) for s,c in sorted(scored,key=lambda x:x[0],reverse=True)[:k] if s>0]
        scores=self.embeddings@qv
        ids=np.argsort(scores)[::-1][:k]
        return [dict(self.chunks[i],score=float(scores[i])) for i in ids]

def generate_answer(question, retrieved, mode="auto"):
    """OpenAI-compatible API or Ollama if configured; otherwise transparent evidence-only fallback."""
    if not retrieved:
        return "I could not find relevant passages in the current knowledge base. Try ingesting articles or reformulating the question."
    evidence="\n\n".join(f"[S{i+1}] {r['title']} ({r['pmcid']}, {r['section']}): {r['text']}" for i,r in enumerate(retrieved))
    prompt=("Answer the user's research question ONLY using the evidence below. Do not add facts not supported. "
           "If evidence is insufficient, clearly say so. Cite sources inline as [S1], [S2]. Distinguish study findings from interpretation. "
           "Do not give personal medical advice.\n\nQUESTION: "+question+"\n\nEVIDENCE:\n"+evidence)
    provider=mode
    if provider=="auto": provider="openai" if os.getenv("OPENAI_API_KEY") else ("ollama" if os.getenv("OLLAMA_MODEL") else "extractive")
    if provider=="openai" and os.getenv("OPENAI_API_KEY"):
        try:
            from openai import OpenAI
            client=OpenAI()
            model=os.getenv("OPENAI_MODEL","gpt-4o-mini")
            res=client.chat.completions.create(model=model,temperature=0.1,messages=[{"role":"system","content":"You are an evidence-grounded literature assistant. Follow the provided evidence strictly and cite [S#]."},{"role":"user","content":prompt}])
            return res.choices[0].message.content.strip()
        except Exception as e: return f"LLM request failed ({e}). Evidence-only fallback follows.\n\n"+extractive_fallback(question,retrieved)
    if provider=="ollama":
        try:
            import requests
            model=os.getenv("OLLAMA_MODEL","llama3.1")
            res=requests.post(os.getenv("OLLAMA_HOST","http://localhost:11434")+"/api/generate",json={"model":model,"prompt":prompt,"stream":False},timeout=180)
            res.raise_for_status(); return res.json().get("response","").strip()
        except Exception as e: return f"Ollama request failed ({e}). Evidence-only fallback follows.\n\n"+extractive_fallback(question,retrieved)
    return extractive_fallback(question,retrieved)

def extractive_fallback(question,retrieved):
    """Transparent non-LLM fallback that quotes selected retrieved snippets, not invented synthesis."""
    lines=["**Evidence-only mode (no generative model configured).** These retrieved passages may help answer the question; this is not a synthesized medical conclusion.",""]
    for i,r in enumerate(retrieved[:4],1):
        excerpt=r["text"][:700].rstrip()
        lines.append(f"**[S{i}] {r['title']} — {r['pmcid']}** ({r.get('section','section')})\n\n> {excerpt}{'…' if len(r['text'])>700 else ''}\n\nSource: {r['url']}")
    lines.append("\nThe knowledge base may not contain enough evidence to answer fully. Review the original papers before drawing conclusions.")
    return "\n".join(lines)


def answer(question, retriever, k=5, provider="auto"):
    docs=retriever.search(question,k)
    text=generate_answer(question,docs,provider)
    return text,docs
