"""Build and save a local index artifact (JSON chunks + embeddings); app can rebuild on startup."""
from pathlib import Path
import json, numpy as np
from rag import load_articles, make_chunks, Embedder
ROOT=Path(__file__).resolve().parents[1]
chunks=make_chunks(load_articles())
(ROOT/"vector_db"/"chunks.json").write_text(json.dumps(chunks,ensure_ascii=False,indent=2),encoding="utf-8")
if chunks:
    emb=Embedder().encode([c["text"] for c in chunks])
    np.save(ROOT/"vector_db"/"embeddings.npy",emb)
print(f"Indexed {len(chunks)} chunks. Embedding model: sentence-transformers if installed; lexical fallback otherwise.")
