"""Simple retrieval smoke tests. Metrics are proxy checks, not a validated clinical benchmark."""
import json, csv
from pathlib import Path
from rag import load_articles, make_chunks, Retriever
ROOT=Path(__file__).resolve().parents[1]

def run():
    tests=json.loads((ROOT/"evaluation"/"test_questions.json").read_text())
    retriever=Retriever(make_chunks(load_articles()))
    rows=[]
    for test in tests:
        hits=retriever.search(test["question"],k=5)
        expected=set(test.get("expected_keywords",[]))
        text=" ".join(h["text"].lower() for h in hits)
        hit=sum(1 for kw in expected if kw.lower() in text)
        rows.append({"question":test["question"],"retrieved_count":len(hits),"keyword_coverage":hit/max(1,len(expected)),"top_source":hits[0]["pmcid"] if hits else ""})
    out=ROOT/"evaluation"/"retrieval_smoke_results.csv"
    with out.open("w",newline="",encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys()); writer.writeheader(); writer.writerows(rows)
    print(f"Wrote {out}; average keyword coverage={sum(r['keyword_coverage'] for r in rows)/max(1,len(rows)):.3f}")
if __name__=="__main__": run()
