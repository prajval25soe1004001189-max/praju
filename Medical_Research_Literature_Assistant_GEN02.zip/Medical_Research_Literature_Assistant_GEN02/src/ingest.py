"""Fetch open-access PMC articles using the NCBI BioC API and save parsed text."""
import argparse, json, re, time
from pathlib import Path
import requests

DATA = Path(__file__).resolve().parents[1] / "data" / "articles.json"
API = "https://www.ncbi.nlm.nih.gov/research/bionlp/RESTful/pmcoa.cgi/BioC_json"

def clean(text):    return re.sub(r"\s+", " ", text or "").strip()

def fetch_pmc(pmcid):
    pmcid = pmcid.upper().replace("PMC", "")
    url = f"{API}/PMC{pmcid}/unicode"
    r = requests.get(url, timeout=40, headers={"User-Agent":"MedicalResearchLiteratureAssistant/1.0 educational project"})
    r.raise_for_status()
    data = r.json()
    passages=[]
    for document in data:
        for passage in document.get("passages", []):
            text=clean(passage.get("text", ""))
            if text:
                inf=passage.get("infons", {})
                passages.append({"section": inf.get("section_type", inf.get("type", "text")), "text":text})
    title=next((p["text"] for p in passages if p["section"].lower() in ("title","front")), f"PMC{pmcid}")
    return {"pmcid":f"PMC{pmcid}", "title":title, "url":f"https://pmc.ncbi.nlm.nih.gov/articles/PMC{pmcid}/", "passages":passages}

def main():
    ap=argparse.ArgumentParser(description="Fetch open-access articles from PMC via BioC API")
    ap.add_argument("pmcids", nargs="+", help="PMC IDs, with or without PMC prefix")
    ap.add_argument("--out", default=str(DATA), help="Output JSON path")
    args=ap.parse_args(); out=Path(args.out)
    articles=[]
    for pid in args.pmcids:
        try:
            article=fetch_pmc(pid); articles.append(article)
            print(f"Fetched {article['pmcid']}: {article['title'][:100]}")
            time.sleep(.34) # courteous pacing
        except Exception as e:
            print(f"Failed {pid}: {e}")
    out.parent.mkdir(parents=True, exist_ok=True)
    existing=[]
    if out.exists():
        try: existing=json.loads(out.read_text(encoding="utf-8"))
        except Exception: existing=[]
    ids={a.get("pmcid") for a in existing}
    combined=existing+[a for a in articles if a["pmcid"] not in ids]
    out.write_text(json.dumps(combined, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Saved {len(combined)} article(s) to {out}")
if __name__ == "__main__": main()
