import streamlit as st
from src.rag import load_articles, make_chunks, Retriever, answer

st.set_page_config(page_title="Medical Research Literature Assistant", page_icon="📚", layout="wide")
st.title("📚 Medical Research Literature Assistant")
st.caption("GEN-02 · Retrieval-Augmented Generation (RAG) · Educational research support")
with st.sidebar:
    st.header("Knowledge base")
    st.write("Ingest open-access PMC articles from the command line first.")
    st.code("python src/ingest.py PMC IDs\npython src/build_index.py", language="bash")
    k=st.slider("Retrieved passages", min_value=2, max_value=10, value=5)
    provider=st.selectbox("Answer engine", ["auto", "extractive", "openai", "ollama"], help="Auto uses OpenAI if API key exists, Ollama if configured, or transparent evidence-only fallback.")
    st.caption("No medical advice. Verify conclusions in original articles.")
articles=load_articles(); chunks=make_chunks(articles)
@st.cache_resource(show_spinner="Indexing article passages…")
def get_retriever(chunks): return Retriever(chunks)
retriever=get_retriever(chunks)
col1,col2,col3=st.columns(3)
col1.metric("Articles indexed",len(articles)); col2.metric("Passages",len(chunks)); col3.metric("Search mode", "Semantic" if retriever.embedder.model else "Keyword fallback")
question=st.text_area("Research question",placeholder="e.g., What limitations do these papers report?",height=100)
if st.button("Search literature",type="primary",disabled=not question.strip()):
    with st.spinner("Retrieving passages and preparing answer…"):
        response,docs=answer(question,retriever,k,provider)
    st.subheader("Evidence-grounded response")
    st.markdown(response)
    st.subheader("Retrieved evidence")
    for i,d in enumerate(docs,1):
        with st.expander(f"[S{i}] {d['title']} · {d['pmcid']} · score {d['score']:.3f}"):
            st.write(d["text"])
            st.markdown(f"[Open original article]({d['url']})")
if not articles:
    st.info("Knowledge base is empty. Fetch PMC articles first, then refresh this page.")
    st.markdown("Example command: `python src/ingest.py PMC1234567 PMC2345678` — replace these with verified PMC IDs.")
st.divider()
st.caption("Research tool only. This app summarizes retrieved literature and is not a diagnostic or treatment system.")
