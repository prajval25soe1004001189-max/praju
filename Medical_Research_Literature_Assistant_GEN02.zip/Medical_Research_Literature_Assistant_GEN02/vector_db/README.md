# Local index
Run `python src/build_index.py` after ingesting articles. Generated chunk and embedding artifacts are local and are not included in the repository ZIP by default.
