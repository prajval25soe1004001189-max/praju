# Data

`articles.json` starts empty. Run `python src/ingest.py <PMC IDs>` to fetch text and metadata for articles through the NCBI BioC API. Check article open-access reuse/license information before storing or redistributing full text. The package intentionally does not bundle a corpus of copyrighted papers.
