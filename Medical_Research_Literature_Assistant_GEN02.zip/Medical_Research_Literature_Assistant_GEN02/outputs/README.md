# Outputs
Generated index artifacts and evaluation CSV files are written here or under `vector_db/` and `evaluation/` when scripts run. No model results are included before execution.
