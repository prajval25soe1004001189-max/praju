# Medical Research Literature Assistant (GEN-02)

## Abstract
This project implements an educational Retrieval-Augmented Generation (RAG) workflow that indexes open-access biomedical literature and retrieves passages relevant to a user's research question. It supports source-linked evidence display and a transparent extractive fallback when a generative model is not configured.

## Problem Statement
Biomedical research information is distributed across articles and can be time-consuming to review. A literature assistant can help users locate relevant passages and summarize retrieved evidence, while retaining source traceability.

## Objectives
1. Ingest open-access PMC article text and metadata.
2. Clean and chunk documents into passages with overlap.
3. Encode passages for similarity-based retrieval.
4. Retrieve evidence for user questions.
5. Generate answers constrained to retrieved passages and cite source labels.
6. Abstain when the knowledge base has no relevant evidence.
7. Provide an interactive Streamlit interface and retrieval smoke tests.

## System Architecture
Article ingestion → text cleaning → chunking → embeddings → vector/semantic retrieval → evidence-grounded generation → citations/source inspection.

## Technology Stack
Python, Streamlit, Requests, NumPy, Sentence Transformers, OpenAI API (optional), Ollama (optional). FAISS is listed as an optional extension; current core retrieval uses normalized-vector similarity or lexical overlap fallback.

## Methodology
Article ingestion is performed through NCBI's BioC service using PMC identifiers. Passages are chunked with a configurable word count and overlap. Sentence Transformer embeddings are used when available; a lexical fallback allows a basic demonstration in constrained environments. Retrieval selects top-k passages. The answer prompt instructs the model to use only retrieved evidence, cite sources as [S#], and report insufficient evidence where appropriate. The interface displays retrieved passage text and links to original article pages.

## Evaluation Plan
Use questions grounded in the ingested papers and add expected keywords for retrieval smoke checks. Assess retrieval coverage, relevance of top passages, citation traceability, abstention behavior, and unsupported-answer risk. The supplied evaluation scaffold is not a validated benchmark; actual results must be generated after a corpus is loaded and the tests are run.

## Limitations
- Retrieval quality depends on the corpus, article availability, chunking, and embedding model.
- Lexical fallback is weaker than semantic retrieval.
- Generated answers may misrepresent evidence despite source citations.
- Article licenses vary; check reuse terms before redistribution.
- This project is not a medical advice, diagnosis, or treatment tool.

## Reproducibility
Install dependencies using `pip install -r requirements.txt`, ingest PMC articles with `python src/ingest.py PMC_ID...`, build artifacts with `python src/build_index.py`, launch using `streamlit run app.py`, and run the smoke tests with `python src/evaluation.py`.

## Results
No performance metrics are reported in this template. Populate this section with measured retrieval/evaluation outputs after ingesting a documented corpus and executing the evaluation script.

## Conclusion
The project demonstrates the main RAG components—document ingestion, chunking, embeddings, retrieval, constrained generation, citations, source inspection, and an interactive UI—in a reproducible educational package. Future work includes hybrid retrieval, reranking, more rigorous citation validation, and a larger expert-reviewed evaluation set.
