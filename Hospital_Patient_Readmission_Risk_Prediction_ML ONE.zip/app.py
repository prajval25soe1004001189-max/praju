import streamlit as st
import pandas as pd
import joblib
from pathlib import Path

ROOT=Path(__file__).resolve().parent
MODEL_PATH=ROOT/'results'/'best_model.joblib'
st.set_page_config(page_title='Readmission Risk Demo',page_icon='🏥',layout='centered')
st.title('Hospital Patient Readmission Risk — Educational Demo')
st.warning('Demo only. Model is trained on synthetic data, not real patient records. Do not use for clinical decisions.')
if not MODEL_PATH.exists():
    st.info('Model file not found. Run: python src/train_evaluate.py')
    st.stop()
model=joblib.load(MODEL_PATH)
with st.form('prediction_form'):
    age=st.selectbox('Age group',['[0-10)','[10-20)','[20-30)','[30-40)','[40-50)','[50-60)','[60-70)','[70-80)','[80-90)','[90-100)'],index=7)
    gender=st.selectbox('Gender',['Female','Male'])
    admission_type=st.selectbox('Admission type',['Emergency','Urgent','Elective'])
    admission_source=st.selectbox('Admission source',['Emergency','Referral','Transfer','Other'])
    discharge=st.selectbox('Discharge disposition',['Home','Home with services','Facility','Other'])
    specialty=st.selectbox('Medical specialty',['Internal Medicine','Family/General','Cardiology','Other'])
    stay=st.slider('Time in hospital (days)',1,14,4)
    labs=st.slider('Lab procedures',1,100,38)
    procedures=st.slider('Procedures',0,20,1)
    meds=st.slider('Number of medications',1,45,14)
    diagnoses=st.slider('Number of diagnoses',1,16,7)
    prior_inpatient=st.slider('Prior inpatient visits',0,8,0)
    prior_emergency=st.slider('Prior emergency visits',0,12,1)
    prior_outpatient=st.slider('Prior outpatient visits',0,20,2)
    diabetes_med=st.selectbox('Diabetes medication',['Yes','No'])
    insulin=st.selectbox('Insulin status',['No','Steady','Up','Down'])
    a1c=st.selectbox('A1C result',['None','Norm','>7',' >8'])
    change=st.selectbox('Medication change',['No','Ch'])
    submitted=st.form_submit_button('Estimate demo score')
if submitted:
    sample=pd.DataFrame([{'age':age,'gender':gender,'admission_type':admission_type,'admission_source':admission_source,
      'discharge_disposition':discharge,'medical_specialty':specialty,'time_in_hospital':stay,
      'num_lab_procedures':labs,'num_procedures':procedures,'num_medications':meds,'num_diagnoses':diagnoses,
      'prior_inpatient':prior_inpatient,'prior_emergency':prior_emergency,'prior_outpatient':prior_outpatient,
      'diabetes_med':diabetes_med,'insulin':insulin,'A1C_result':a1c,'medication_change':change}])
    p=float(model.predict_proba(sample)[0,1])
    st.metric('Synthetic model score',f'{p:.1%}')
    st.caption('This is a model score on simulated data. It is not a validated medical risk estimate.')
