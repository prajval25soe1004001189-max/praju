from pathlib import Path
import json, joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, classification_report
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'/'synthetic_readmission_demo.csv'
OUT=ROOT/'results'
OUT.mkdir(exist_ok=True)
df=pd.read_csv(DATA)
target='readmitted_30d'
X=df.drop(columns=[target]); y=df[target]
cat_cols=X.select_dtypes(include='object').columns.tolist()
num_cols=X.select_dtypes(exclude='object').columns.tolist()
pre=ColumnTransformer([
 ('num',Pipeline([('imputer',SimpleImputer(strategy='median')),('scale',StandardScaler())]),num_cols),
 ('cat',Pipeline([('imputer',SimpleImputer(strategy='most_frequent')),('onehot',OneHotEncoder(handle_unknown='ignore'))]),cat_cols)
])
models={
 'Logistic Regression':LogisticRegression(max_iter=1200,class_weight='balanced'),
 'Random Forest':RandomForestClassifier(n_estimators=250,min_samples_leaf=2,class_weight='balanced',random_state=17,n_jobs=-1),
 'HistGradientBoosting':HistGradientBoostingClassifier(max_iter=150,learning_rate=.08,max_leaf_nodes=20,random_state=17)
}
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=17,stratify=y)
rows=[]; fitted={}
for name,m in models.items():
 pipe=Pipeline([('preprocess',pre),('model',m)])
 pipe.fit(Xtr,ytr); fitted[name]=pipe
 pred=pipe.predict(Xte); proba=pipe.predict_proba(Xte)[:,1]
 row={'Model':name,'Accuracy':accuracy_score(yte,pred),'Precision':precision_score(yte,pred,zero_division=0),
 'Recall':recall_score(yte,pred,zero_division=0),'F1':f1_score(yte,pred,zero_division=0),'ROC_AUC':roc_auc_score(yte,proba)}
 rows.append(row)
metrics=pd.DataFrame(rows).sort_values('F1',ascending=False)
metrics.to_csv(OUT/'model_metrics.csv',index=False)
bestname=metrics.iloc[0]['Model']; best=fitted[bestname]
joblib.dump(best,OUT/'best_model.joblib')
(OUT/'model_summary.txt').write_text(metrics.to_string(index=False)+'\n\nSelected by F1: '+bestname,encoding='utf-8')
pred=best.predict(Xte); cm=confusion_matrix(yte,pred)
plt.figure(figsize=(5,4)); plt.imshow(cm); plt.title('Confusion Matrix'); plt.xlabel('Predicted'); plt.ylabel('Actual')
plt.xticks([0,1],['No','Yes']); plt.yticks([0,1],['No','Yes'])
for (i,j),v in __import__('numpy').ndenumerate(cm): plt.text(j,i,str(v),ha='center',va='center')
plt.tight_layout(); plt.savefig(OUT/'confusion_matrix.png',dpi=150); plt.close()
print(metrics.to_string(index=False))
print('\nBest model:',bestname)
print(classification_report(yte,pred,zero_division=0))
