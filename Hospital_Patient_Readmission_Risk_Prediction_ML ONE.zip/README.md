# Hospital Patient Readmission Risk Prediction (Bleep ML-02)

## Project status
Runnable educational prototype complete. **All current metrics and demo predictions are from synthetic data** generated for this project. This is not the UCI Diabetes 130-US Hospitals dataset and is not clinically validated.

## Objective
Demonstrate an end-to-end ML classification workflow to explore a simulated 30-day readmission label.

## Features (synthetic)
- Age group, gender, admission type/source, discharge disposition, specialty
- Length of stay, lab/procedure counts, medication and diagnosis counts
- Prior inpatient/emergency/outpatient encounter counts
- Diabetes medication, insulin, A1C result, medication-change indicators

## ML pipeline
- Stratified 80/20 train-test split
- Numeric median imputation and standard scaling
- Categorical most-frequent imputation and one-hot encoding
- Class-weighting for Logistic Regression and Random Forest
- Compare Logistic Regression, Random Forest, HistGradientBoosting
- Report accuracy, precision, recall, F1 and ROC-AUC
- Confusion matrix and ROC plot

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python src/train_evaluate.py
streamlit run app.py
```

## Project structure
- `data/` synthetic demo data; source note
- `src/train_evaluate.py` training and evaluation
- `app.py` Streamlit demo UI
- `notebooks/` notebook for EDA/modeling
- `results/` generated metrics and charts
- `reports/` report files

## Dataset source for real-data extension
The internship brief identifies the **Diabetes 130-US Hospitals for Years 1999–2008** dataset and links to UCI Machine Learning Repository. Download it from the official dataset page and check its license/terms. This package does not include the real dataset. Before using it, carefully define the target (e.g., `readmitted == '<30'` as positive) and exclude target leakage columns. Re-run evaluation and replace synthetic results in the report with measured real-data results.

## Responsible use
This project is for learning only. It must not be used for clinical decisions, diagnosis, treatment, patient prioritization, or real patient care. Synthetic patterns and scores do not represent actual patient risk.
